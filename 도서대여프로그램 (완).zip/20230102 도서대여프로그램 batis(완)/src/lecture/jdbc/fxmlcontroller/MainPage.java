package lecture.jdbc.fxmlcontroller;

public interface MainPage {
	
	public void setArgAndRender(String idtext); 

}
